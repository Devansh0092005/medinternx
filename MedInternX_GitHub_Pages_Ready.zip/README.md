# MedInternX — GitHub Pages Ready

This is a static, free-to-host MedInternX website. **No Node.js is required.**

## Publish on GitHub Pages
1. Create a GitHub account and a new repository (example: `medinternx`).
2. Upload `index.html`, `style.css`, `script.js`, and this README to the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. GitHub will show your live website address.

## Included
- MedInternX branding and tagline
- Six internships
- Responsive modern design
- Registration/login demo UI
- Free internship messaging
- Certificate fee hidden until completion concept
- No Node.js required

## Important
GitHub Pages is static hosting, so the included forms are demos and do not store real student accounts. For real accounts, progress, admin features and certificate/payment processing, connect a backend/database such as Supabase plus a secure payment backend.

The ₹49 certificate price is intentionally not shown publicly or before completion.
